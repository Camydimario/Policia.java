import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 *  Una ParedIrrompible es un obstáculo que no puede ser destruido.
 */
public class ParedIrrompible extends ActorBase
{
    /**
     * Act - do whatever the ParedIrrompible wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void actualizarImagen()
    {
        int tamCelda = getWorld().getCellSize();
        GreenfootImage image = getImage();
        image.scale(tamCelda, tamCelda);
        setImage(image);
    }
}
