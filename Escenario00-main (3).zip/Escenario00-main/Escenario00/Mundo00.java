import greenfoot.*;

public class Mundo00 extends MundoBase {

    public Mundo00() {
        super(18, 18);
        prepare();
    }

    /**
     * genera naves en la ubicacion establecida
     */
    protected void generarNaves() {
        //agregar(new NaveExploradora(), 5, 5);
        agregar(new NaveDeAtaque(), 1, 2);

        agregar(new NaveExploradoraEnemiga(Direccion.NORTE), 6, 6);
        agregar(new NaveExploradoraEnemiga(Direccion.NORTE), 4, 10);
        agregar(new NaveExploradoraEnemiga(Direccion.NORTE), 12, 13);

        agregar(new NaveDeAtaqueEnemiga(Direccion.SUR), 10, 4);
        agregar(new NaveDeAtaqueEnemiga(Direccion.SUR), 11, 4);
        agregar(new NaveDeAtaqueEnemiga(Direccion.SUR), 12, 4);
        agregar(new NaveDeAtaqueEnemiga(Direccion.OESTE), 4, 7);
        agregar(new NaveDeAtaqueEnemiga(Direccion.OESTE), 7, 7);
        agregar(new NaveDeAtaqueEnemiga(Direccion.OESTE), 7, 5);
        agregar(new NaveDeAtaqueEnemiga(Direccion.NORTE), 3, 4);
        agregar(new NaveDeAtaqueEnemiga(Direccion.SUR), 16, 5);
        agregar(new NaveDeAtaqueEnemiga(Direccion.NORTE), 5, 3);
        //Custodian la llave
        agregar(new NaveDeAtaqueEnemiga(Direccion.OESTE), 10, 8);
        agregar(new NaveDeAtaqueEnemiga(Direccion.NORTE), 10, 7);
        agregar(new NaveDeAtaqueEnemiga(Direccion.NORTE), 11, 7);
        agregar(new NaveDeAtaqueEnemiga(Direccion.NORTE), 12, 7);
        agregar(new NaveDeAtaqueEnemiga(Direccion.ESTE), 12, 8);

        //Custodian la llave dark
        agregar(new NaveDeAtaqueEnemiga(Direccion.OESTE), 15, 14);
        agregar(new NaveDeAtaqueEnemiga(Direccion.NORTE), 15, 15);
        agregar(new NaveDeAtaqueEnemiga(Direccion.OESTE), 14, 16);
        agregar(new NaveDeAtaqueEnemiga(Direccion.OESTE), 14, 15);
        agregar(new NaveDeAtaqueEnemiga(Direccion.OESTE), 16, 16);
        agregar(new NaveDeAtaqueEnemiga(Direccion.OESTE), 16, 15);

        //Custodian el portal
        agregar(new NaveDeAtaqueEnemiga(Direccion.NORTE), 16, 7);
        agregar(new NaveDeAtaqueEnemiga(Direccion.OESTE), 16, 8);

        //Cuadrante sur
        agregar(new NaveDeAtaqueEnemiga(Direccion.OESTE), 5, 12);
        agregar(new NaveDeAtaqueEnemiga(Direccion.OESTE), 8, 10);
        agregar(new NaveDeAtaqueEnemiga(Direccion.OESTE), 9, 11);
        agregar(new NaveDeAtaqueEnemiga(Direccion.OESTE), 11, 10);
        agregar(new NaveDeAtaqueEnemiga(Direccion.OESTE), 8, 13);
        agregar(new NaveDeAtaqueEnemiga(Direccion.OESTE), 4, 13);
        agregar(new NaveDeAtaqueEnemiga(Direccion.OESTE), 6, 11);
        agregar(new NaveDeAtaqueEnemiga(Direccion.OESTE), 8, 15);
        agregar(new NaveDeAtaqueEnemiga(Direccion.OESTE), 11, 12);
        agregar(new NaveDeAtaqueEnemiga(Direccion.OESTE), 10, 16);
        agregar(new NaveDeAtaqueEnemiga(Direccion.SUR), 16, 11);
        agregar(new NaveDeAtaqueEnemiga(Direccion.SUR), 15, 11);

    }

    /**
     * genera puntos de interes
     */
    protected void generarPOIs() {
        marcarCelda(1, 2, new Color(0, 0, 200, 150));
        marcarCelda(1, 2, new Color(200, 0, 0, 150));
    }

    /**
     * genera items consumibles en la ubicacion establecida
     */
    protected void generarItems() {
        agregar(new Item(), 3, 17);
        agregar(new Item(), 15, 2);// combustible
        agregar(new Item(), 2, 1);
        agregar(new Item(), 14, 11);
        agregar(new Item(), 3, 16);
        agregar(new Item(),4, 8);
        agregar(new Item(), 14, 8);
        agregar(new Item(), 3, 10);
        agregar(new Item(), 13, 16);

        agregar(new Item(), 6, 16);
        agregar(new Item(), 6, 12);
        agregar(new Item(), 7, 12);
        agregar(new Item(), 5, 7);
        agregar(new Item(), 11, 6);
        agregar(new Item(), 13,7);
    }

    /**
     * genera asteroides en la ubicacion establecida
     */
    protected void generarAsteroides() {
        agregar(new AsteroideDeMineral(), 7, 2);

        agregar(new Asteroide(), 7, 3);
        agregar(new Asteroide(), 8, 4);
        agregar(new Asteroide(),9, 5);

        agregar(new Asteroide(), 10, 14);
        agregar(new Asteroide(), 11, 15);
        agregar(new Asteroide(), 12, 16);

        agregar(new Asteroide(), 12, 10);
        agregar(new Asteroide(), 13, 11);
        agregar(new Asteroide(), 14, 12);

    }

    /**
     * genera ParedeIrromplibe en la ubicacion establecida
     */protected void generarParedes() {
        // Columnas Izquierda
        agregar(new ParedIrrompible(), 1, 1);
        agregar(new ParedIrrompible(), 1, 3);
        agregar(new ParedIrrompible(), 1, 4);
        agregar(new ParedIrrompible(), 1, 5);
        agregar(new ParedIrrompible(), 1, 6);
        agregar(new ParedIrrompible(), 1, 7);
        agregar(new ParedIrrompible(), 1, 8);
        agregar(new ParedIrrompible(), 1, 9);
        agregar(new ParedIrrompible(), 1, 11);
        agregar(new ParedIrrompible(), 1, 12);
        agregar(new ParedIrrompible(), 1, 13);
        agregar(new ParedIrrompible(), 1, 14);
        agregar(new ParedIrrompible(), 1, 15);
        agregar(new ParedIrrompible(), 1, 16);
        agregar(new ParedIrrompible(), 1, 17);

        // Filas Superior
        agregar(new ParedIrrompible(), 2, 1);
        agregar(new ParedIrrompible(), 3, 1);
        agregar(new ParedIrrompible(), 4, 1);
        agregar(new ParedIrrompible(), 5, 1);
        agregar(new ParedIrrompible(), 6, 1);
        agregar(new ParedIrrompible(), 7, 1);
        agregar(new ParedIrrompible(), 8, 1);
        agregar(new ParedIrrompible(), 9, 1);
        agregar(new ParedIrrompible(), 10, 1);
        agregar(new ParedIrrompible(), 11, 1);
        agregar(new ParedIrrompible(), 12, 1);
        agregar(new ParedIrrompible(), 13, 1);
        agregar(new ParedIrrompible(), 14, 1);
        agregar(new ParedIrrompible(), 15, 1);
        agregar(new ParedIrrompible(), 16, 1);
        agregar(new ParedIrrompible(), 17, 1);

        // Columna Derecha
        agregar(new ParedIrrompible(), 17, 2);
        agregar(new ParedIrrompible(), 17, 3);
        agregar(new ParedIrrompible(), 17, 4);
        agregar(new ParedIrrompible(), 17, 5);
        agregar(new ParedIrrompible(), 17, 6);
        agregar(new ParedIrrompible(), 17, 7);

        agregar(new ParedIrrompible(), 17, 9);
        agregar(new ParedIrrompible(), 17, 10);
        agregar(new ParedIrrompible(), 17, 11);
        agregar(new ParedIrrompible(), 17, 12);
        agregar(new ParedIrrompible(), 17, 13);
        agregar(new ParedIrrompible(), 17, 14);
        agregar(new ParedIrrompible(), 17, 15);
        agregar(new ParedIrrompible(), 17, 16);

        // Filas Inferior
        agregar(new ParedIrrompible(), 2, 17);
        agregar(new ParedIrrompible(), 3, 17);
        agregar(new ParedIrrompible(), 4, 17);
        agregar(new ParedIrrompible(), 5, 17);
        agregar(new ParedIrrompible(), 6, 17);
        agregar(new ParedIrrompible(), 7, 17);
        agregar(new ParedIrrompible(), 8, 17);
        agregar(new ParedIrrompible(), 9, 17);
        agregar(new ParedIrrompible(), 10, 17);
        agregar(new ParedIrrompible(), 11, 17);
        agregar(new ParedIrrompible(), 12, 17);
        agregar(new ParedIrrompible(), 13, 17);
        agregar(new ParedIrrompible(), 14, 17);
        agregar(new ParedIrrompible(), 15, 17);
        agregar(new ParedIrrompible(), 16, 17);

        // Medio
        // Divisoria de Norte y Sur
        agregar(new ParedIrrompible(), 2, 9);
        agregar(new ParedIrrompible(), 3, 9);
        agregar(new ParedIrrompible(), 4, 9);
        agregar(new ParedIrrompible(), 5, 9);
        agregar(new ParedIrrompible(), 6, 9);
        agregar(new ParedIrrompible(), 7, 9);
        agregar(new ParedIrrompible(), 8, 9);
        agregar(new ParedIrrompible(), 9, 9);
        agregar(new ParedIrrompible(), 10, 9);
        agregar(new ParedIrrompible(), 11, 9);
        agregar(new ParedIrrompible(), 12, 9);
        agregar(new ParedIrrompible(), 13, 9);
        agregar(new ParedIrrompible(), 14, 9);
        agregar(new ParedIrrompible(), 15, 9);
        agregar(new ParedIrrompible(), 16, 9);

        //Presidio Galactico

        agregar(new ParedIrrompible(), 5, 14);
        agregar(new ParedIrrompible(), 5, 15);
        agregar(new ParedIrrompible(), 4, 14);
        agregar(new ParedIrrompible(), 3, 14);
        agregar(new ParedIrrompible(), 2, 14);

        // Reabastecimiento
        agregar(new ParedIrrompible(), 13, 2);
        agregar(new ParedIrrompible(), 13, 3);
        agregar(new ParedIrrompible(), 13, 4);
        agregar(new ParedIrrompible(), 14, 4);
        agregar(new ParedIrrompible(), 15, 4);

    }

    /**
     * genera puerta en la ubicacion establecida
     */
    protected void generarPuertas() {
        agregar(new PuertaCerrada(),16,4);
        agregar(new PuertaDark(), 5, 16);
    }

    /**
     * genera una Llave en la ubicacion establecida
     */
    protected void generarLlave() {
        agregar(new Llave(), 11, 8);
    }

    /**
     * genera una LlaveDark en la ubicacion establecida
     */
    protected void generarLlaveDark() {
        agregar(new LlaveDark(), 15, 16);
    }

    /**
     * genera portales en la ubicacion establecida
     */
    protected void generarPortales() {
        // Portal transporta a las cordenadas del tablero 
        agregar(new Portal(16, 8), 1, 10);
        // Portal transporta a las cordenadas del tablero 
        agregar(new Portal(2, 10), 17, 8);

    }

    /**
     * genera un PilotoDeEjemplo en la ubicacion establecida
     */
    protected void generarPiloto() {
        agregar(new PilotoDeEjemplo(), 11, 5);
    }

    /**
     * genera un Escudo en la ubicacion establecida
     */
    protected void generarEscudo(){
        agregar(new Escudo(), 14, 2);
        agregar(new Escudo(), 2, 15);
        agregar(new Escudo(), 13, 10);
    }

    /**
     * genera una Bomba en la ubicacion establecida
     */
    protected void generarBomba(){
        //agregar(new Bomba(),8,5);
    }

    /**
     * genera una TarjetaActivadora en la ubicacion establecida
     */protected void generarTarjetaActivadora(){
        agregar(new TarjetaActivadora(), 16, 2);
    }

    /**
     * genera un PilotoRescatado en la ubicacion establecida
     */
    protected void generarPilotoRescatado(){
        agregar(new PilotoRescatado(), 2, 16);
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
    }
}
