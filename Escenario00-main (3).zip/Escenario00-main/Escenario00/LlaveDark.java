import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Define un LlaveDark en la Batalla Espacial
 */
public class LlaveDark extends ActorBase {

    
    private double ESCALA_X = 0.9;
    private double ESCALA_Y = 0.9;

    /**
     * Establece la imagen con la escala definida
     */
    @Override
    protected void actualizarImagen() {
        int tamCelda = getWorld().getCellSize();
        GreenfootImage image = getImage();
        image.scale((int) (tamCelda * ESCALA_X), (int) (tamCelda * ESCALA_Y));
        setImage(image);
    }

    /**
     * post: la LlaveDark desaparece del mundo
     * 
     * @return si la LlaveDark fue recogida
     */
    public boolean serRecogido() {
        getWorld().removeObject(this);
        Greenfoot.delay(20);
        return true;
    }
}
