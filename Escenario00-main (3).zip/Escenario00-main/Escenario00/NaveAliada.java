import greenfoot.Color;
import greenfoot.*;

/**
 * Define características y comportamientos comunes a todas las Naves Aliadas de
 * la Batalla Espacial. Entre ellas, su uso de combustible.
 */
public abstract class NaveAliada extends NaveBase {
    /**
     * El combustible de la NaveAliada. Toda acción insume combustible
     */
    protected int combustible;

    /**
     * Indica si la nave tiene la llave o no
     */
    protected boolean llave = false;

    /**
     * Indica si la nave tiene la llaveDark o no
     */
    protected boolean llaveDark = false;

    /**
     * Indica el valor del escudo 
     */
    protected int escudo;
    /**
     * Indica si la nave tiene la tarjeta
     */
    protected boolean tarjeta = false;

    /**
     * Indica si la nave tiene al piloto rescatado
     */
    protected boolean rescatado = false;

    /**
     * Inicializa una NaveAliada con el {@link #obtenerCombustibleMaximo()}
     */
    public NaveAliada() {
        super();
        this.combustible = obtenerCombustibleMaximo();
        this.escudo = 0;
    }

    /**
     * Punto de extensión para obtener el combustible máximo para un tipo de
     * NaveAliada
     * 
     * @return la cantidad de combustible máximo que carga la NaveAliada
     */
    abstract int obtenerCombustibleMaximo();

    /**
     * Punto de extensión para obtener el combustible consumido por moverse
     * 
     * @return la cantidad de combustible que consume realizar un movimiento
     */
    abstract int obtenerConsumoPorMovimiento();

    /**
     * Permite a una NaveAliada recibir combustible. <br>
     * post: La NaveAliada recibe la cantidad de combustible deseado, limitado a la
     * carga máxima de la que puede disponer
     * 
     * @param cantidad es la cantidad de combustible que intenta recibir
     */
    public void recibirCombustible(int cantidad) {
        this.combustible = Math.min(this.combustible + cantidad, obtenerCombustibleMaximo());
        actualizarImagen();
    }

    /**
     * Post:El estado de la nave se actualiza visualmente y, si corresponde, se reduce el escudo o el combustible.
     * Permite que la {@code NaveAliada} reciba daño de un {@link Atacante}.
     * - Si la nave tiene escudo activo ({@code escudo > 0}), el escudo absorbe el impacto y se reduce en 1 unidad.
     * - Si no tiene escudo, la nave pierde una cantidad de {@link #combustible} igual al daño infligido por el atacante.
     * - En ambos casos, se actualiza la imagen de la nave y se genera una {@link Explosion} en la posición actual.
     * @param atacante El objeto que realiza el ataque y del cual se obtiene la cantidad de daño.
     */
    public void recibirDañoDe(Atacante atacante) {
        if(this.escudo > 0){
            this.escudo-=1;
        } else {
            int daño = atacante.obtenerDaño();
            this.combustible -= daño;
        }
        actualizarImagen();
        Explosion.en(getWorld(), this.getX(), this.getY());
    }

    /**
     * post: la cantidad de {@link #combustible} se reduce en la cantidad
     * solicitada, o llega a cero si no alcanzase
     * 
     * @param cantidad es la cantidad de combustible que se consumirá
     */
    protected void consumirCombustible(int cantidad) {
        this.combustible -= Math.min(cantidad, this.combustible);
        actualizarImagen();
    }

    /**
     * post: carga la cantidad de {@link #combustible} solicitado, o llega a
     * {@link #obtenerCombustibleMaximo()} si éste se excediera del que puede llevar
     * 
     * @param combustible es la cantidad de combustible a cargar
     */
    public void cargarCombustible(int combustible) {
        this.combustible = Math.min(obtenerCombustibleMaximo(), this.combustible + combustible);
        actualizarImagen();
    }
    
    /**
     * Verifica si agarra una llave y actualiza la imagen
     */
    public void agarrarLlave() {
        this.llave = true;
        actualizarImagen();
    }
    
    /**
     * Verifica si agarra una llaveDark  y actualiza la imagen
     */
    public void agarrarLlaveDark() {
        this.llaveDark = true;
        actualizarImagen();
    }

    /**
     * Verifica si agarra un escudo y actualiza la imagen
     */
    public void agarrarEscudo() {
        this.escudo = 3;
        actualizarImagen();
    }

    /**
     * Verifica si agarra la tarjeta activadora y actualiza la imagen 
     */
    public void agarrarTarjetaActivadora() {
        this.tarjeta = true;
        actualizarNaveFinal();

    }

    /**
     * Verifica si agarra al piloto para rescatar y actualiza la imagen 
     */
    public void agarrarPilotoRescatado() {
        this.rescatado = true;
        actualizarNaveFinalConPiloto();
    }

    /**
     * {@link #combustible}
     * 
     * @return la cantidad de combustible actual
     */
    public int obtenerCombustible() {
        return this.combustible;
    }

    /**
     * Calcula la proporción de la barra indicadora en función al
     * {@link #combustible} y a {@link #obtenerCombustibleMaximo()}
     * 
     * @return la proporción de la barra indicadora a mostrar
     */
    protected double obtenerProporcionDeBarraIndicadora() {
        return 1.0 * combustible / obtenerCombustibleMaximo();
    }

    /**
     * @return el color de la barra indicadora de la {@link NaveAliada}
     */
    @Override
    protected Color obtenerColorDeBarraIndicadora() {
        return Color.BLUE;
    }

    /**
     * @return si la nave está en condiciones de actuar
     */
    @Override
    protected boolean puedeActuar() {
        return this.combustible > 0;
    }

    /**
     * define la funcion de mover hacia:
     * no se mueve si no puede actuar o no tiene combustible
     * se mueve a x direccion si puede
     * cosume combustible por movimiento
     * al tocar un item,obtiene combustible
     * al tocar un portal se teletransporta a la direccion del otro portal
     * recoje la llave
     * recoje la llavedark
     * al tocar el escudo,este lo recoje y activa
     * 
     * al tocar la tarjeta,este la recoge y activa
     * al tocar al pilotorescatado,este lo recoge
     * si se cumple cualquier punto,devuelve true
     */
    @Override
    protected boolean moverHacia(Direccion direccion) {
        if (!puedeActuar() || this.combustible < obtenerConsumoPorMovimiento()) {
            return false;
        }
        if (!super.moverHacia(direccion)) {
            return false;
        }
        consumirCombustible(obtenerConsumoPorMovimiento());
        Item item = (Item) getOneObjectAtOffset(0, 0, Item.class);
        if (item != null) {
            this.cargarCombustible(item.serRecogido());
        }
        Portal portal = (Portal) getOneObjectAtOffset(0, 0, Portal.class);
        if (portal != null) {
            this.setLocation(portal.devolverDestX(), portal.devolverDestY());
        }
        Llave llave = (Llave) getOneObjectAtOffset(0, 0, Llave.class);
        if (llave != null) {
            this.agarrarLlave();
            llave.serRecogido();
        }
        LlaveDark llaveDark = (LlaveDark) getOneObjectAtOffset(0, 0, LlaveDark.class);
        if (llaveDark != null) {
            this.agarrarLlave();
            llaveDark.serRecogido();
        }
        Escudo escudo = (Escudo) getOneObjectAtOffset(0, 0, Escudo.class);
        if (escudo != null) {
            this.agarrarEscudo();
            escudo.serRecogido();
        }
        Bomba bombita = (Bomba) getOneObjectAtOffset(0, 0, Bomba.class);
        if (bombita != null) {
            
        }
        TarjetaActivadora tarjeta = (TarjetaActivadora ) getOneObjectAtOffset(0, 0, TarjetaActivadora.class);
        if (tarjeta  != null) {
            this.agarrarTarjetaActivadora ();
            tarjeta.serRecogido();
        }
        PilotoRescatado rescatado = ( PilotoRescatado) getOneObjectAtOffset(0, 0,  PilotoRescatado.class);
        if ( rescatado != null) {
            this.agarrarPilotoRescatado();
            rescatado.serRecogido();
        }

        return true;

    }

    /**
     * Define una forma de inspeccionar el entorno
     * 
     * @param direccion es la dirección que desea inspeccionar
     * @return si hay un {@link Asteroide} a una casilla de distancia, en la
     *         dirección deseada
     */
    public boolean hayAsteroideHacia(Direccion direccion) {
        return super.hayActorHacia(Asteroide.class, direccion);
    }

    /**
     * Define una forma de inspeccionar el entorno
     * 
     * @param direccion es la dirección que desea inspeccionar
     * @return si hay un {@link Item} a una casilla de distancia, en la dirección
     *         deseada
     */
    public boolean hayItemHacia(Direccion direccion) {
        return super.hayActorHacia(Item.class, direccion);
    }

    /**
     * Define una forma de inspeccionar el entorno
     * 
     * @param direccion es la dirección que desea inspeccionar
     * @return si hay una {@link NaveBase} a una casilla de distancia, en la
     *         dirección deseada
     */
    public boolean hayNaveHacia(Direccion direccion) {
        return super.hayActorHacia(NaveBase.class, direccion);
    }

    /**
     * Define una forma de inspeccionar el entorno
     * 
     * @param direccion es la dirección que desea inspeccionar
     * @return si hay una {@link PuertaCerrada1} a una casilla de distancia, en la
     *         dirección deseada
     */
    public boolean hayPuertaHacia(Direccion direccion) {
        return super.hayActorHacia(PuertaCerrada.class,  direccion);
    }

    /**
     * Define una forma de inspeccionar el entorno
     * 
     * @param direccion es la dirección que desea inspeccionar
     * @return si hay una {@link PuertaCerrada2} a una casilla de distancia, en la
     *         dirección deseada
     */

    public boolean hayPuertaHacia1(Direccion direccion) {
        return super.hayActorHacia(PuertaDark.class,  direccion);
    }

    /**
     * Define una forma de inspeccionar el entorno
     * 
     * @param direccion es la dirección que desea inspeccionar
     * @return si el mundo se acaba a una casilla de distancia, en la dirección
     *         deseada
     */
    public boolean hayVacioHacia(Direccion direccion) {
        int width = getWorld().getWidth() - 1;
        int height = getWorld().getHeight() - 1;
        int x = getX();
        int y = getY();

        switch (direccion) {
            case NORTE:
                return y == 0;
            case SUR:
                return y == height;
            case ESTE:
                return x == width;
            case OESTE:
                return x == 0;
        }
        return false;
    }

    /**
     * Verifica si la nave está en alguno de los bordes del Mundo
     * 
     * @return {@code true} si está en el borde
     */
    public boolean estaEnElBorde() {
        return isAtEdge();
    }

    /**
     * Verifica si la nave tiene la llave llave y si hay una puerta en la direccion
     * indicada para luego abrirla <br>
     * pre: la NaveAliada debe tener {@link #llaveDark} en {@code true}, y la celda
     * destino debe contener {@link PuertaCerrada} <br>
     * post: la {@link PuertaCerrada} desaparece
     * 
     * @param direccion es la dirección en donde se encuentra la puerta a abrir
     */

    public void abrirPuerta(Direccion direccion) {
        if (llave  && hayPuertaHacia(direccion) && puedeActuar()) {
            this.direccion = direccion;
            actualizarImagen();
            setRotation(direccion.rotacion);
            Greenfoot.delay(20);
            PuertaCerrada puerta = (PuertaCerrada) getOneObjectAtOffset(this.direccion.dx, this.direccion.dy,
                    PuertaCerrada.class);
            if (puerta != null) {
                puerta.puertaAbierta();
            }

        }
    }

    /**
     * Verifica si la nave tiene la llave llaveDark y si hay una puerta en la direccion
     * indicada para luego abrirla <br>
     * pre: la NaveAliada debe tener {@link #llaveDark} en {@code true}, y la celda
     * destino debe contener {@link PuertaCerrada} <br>
     * post: la {@link PuertaCerrada} desaparece
     * 
     * @param direccion es la dirección en donde se encuentra la puerta a abrir
     */

    public void abrirPuertaDark(Direccion direccion) {
        if (llave && hayPuertaHacia1(direccion) && puedeActuar()) {
            this.direccion = direccion;
            actualizarImagen();
            setRotation(direccion.rotacion);
            Greenfoot.delay(20);
            PuertaDark puerta = (PuertaDark) getOneObjectAtOffset(this.direccion.dx, this.direccion.dy,
                    PuertaDark.class);
            if (puerta != null) {
                puerta.puertaAbiertaDark();
            }

        }
    }

    /**
     * post: Actualiza la imagen de la nave cuando agarra la 
     * tarjeta activadora de bomba
     */
    public void actualizarNaveFinal(){
        int tamCelda = getWorld().getCellSize();
        imagenBase = new GreenfootImage("weaponized-ship-final.png");
        imagenBase.scale((int) (tamCelda * ESCALA_X), (int) (tamCelda * ESCALA_Y));
        actualizarImagen();
    }

    /**
     * post: Actualiza la imagen de la nave cuando agarra al  
     * piloto
     */
    public void actualizarNaveFinalConPiloto(){
        int tamCelda = getWorld().getCellSize();
        imagenBase = new GreenfootImage("actualizarNaveFinalConPiloto.png");
        imagenBase.scale((int) (tamCelda * ESCALA_X), (int) (tamCelda * ESCALA_Y));
        actualizarImagen();
    }

}
