import greenfoot.*;
import java.util.LinkedList;
import java.util.List;
import java.util.ArrayList;

public class NaveDeAtaque extends NaveAliada implements Atacante {

    /**
     * Representa el estado de los motores de la {@link NaveDeAtaque}.
     */
    protected boolean motoresEncendidos = false;

    protected boolean  serRecogido = false;
    protected PilotoBase piloto;

    protected LinkedList<Direccion> movimientos = new LinkedList<Direccion>();

    /**
     * Inicializa una nueva NaveDeAtaque con los motores apagados
     */
    public NaveDeAtaque() {
        super();
    }

    /**
     * Inicializa una nueva NaveDeAtaque con los motores apagados. Este constructor
     * es empleado mayormente para la creación de escenarios.
     * 
     * @param direccion es la orientación con la que se creará la NaveDeAtaque
     * @param carga     es la carga de combustible inicial de la NaveDeAtaque
     */
    public NaveDeAtaque(Direccion direccion, int carga) {
        super();
        setDireccion(direccion);
        this.combustible = carga;
    }

    /**
     * pre: posee combustible {@link NaveAliada#combustible} y los motores se
     * encuentran apagados {@link NaveDeAtaque#motoresEncendidos} <br/>
     * post: encenderá sus motores
     */
    public void encenderMotores() {
        if (this.combustible > 0 && !this.motoresEncendidos) {
            this.motoresEncendidos = true;
            Greenfoot.playSound("engine-on.wav");
            int tamCelda = getWorld().getCellSize();
            imagenBase = new GreenfootImage("weaponized-ship-on.png");
            imagenBase.scale((int) (tamCelda * ESCALA_X), (int) (tamCelda * ESCALA_Y));
            actualizarImagen();
        }
    }

    /**
     * pre: los motores se encuentran encendidos
     * {@link NaveDeAtaque#motoresEncendidos} <br/>
     * post: apagará sus motores
     */
    public void apagarMotores() {
        if (this.motoresEncendidos) {
            this.motoresEncendidos = false;
            Greenfoot.playSound("engine-off.wav");
            int tamCelda = getWorld().getCellSize();
            imagenBase = new GreenfootImage("weaponized-ship.png");
            imagenBase.scale((int) (tamCelda * ESCALA_X), (int) (tamCelda * ESCALA_Y));
            actualizarImagen();
        }
    }

    /**
     * @return {@code true} si puede actuar según la lógica heredada y si los motores están encendidos; 
     * {@code false} en caso contrario.
     */
    protected boolean puedeActuar() {
        return super.puedeActuar() && this.motoresEncendidos;
    }

    /**
     * {@inheritDoc} <br>
     * post: si se agota el {@link NaveAliada#combustible}, se apagarán los motores
     * @param cantidad
     */
    protected void consumirCombustible(int cantidad) {
        super.consumirCombustible(cantidad);
        if (combustible <= 0) {
            this.apagarMotores();
        }
    }

    /**
     * pre: La NaveDeAtaque {@link #puedeActuar()} <br>
     * post: El {@link NaveAliada#combustible} se reducirá en
     * {@link #obtenerConsumoPorAtaque()}. Si en la dirección deseada hay un
     * {@link Dañable}, éste recibirá {@link #obtenerDaño()}.
     * 
     * @param direccion
     */
    public void atacarHacia(Direccion direccion) {
        if (!puedeActuar()) {
            return;
        }
        this.direccion = direccion;
        actualizarImagen();
        setRotation(direccion.rotacion);
        Greenfoot.delay(20);
        consumirCombustible(obtenerConsumoPorAtaque());

        Actor actor = getOneObjectAtOffset(this.direccion.dx, this.direccion.dy, Actor.class);
        if (!(actor instanceof Dañable)) {
            return;
        }
        Dañable objetivo = (Dañable) actor;
        if (objetivo != null) {
            Greenfoot.playSound("laser-shot.mp3");
            objetivo.recibirDañoDe(this);
        }
    }

    /**
     * @see NaveAliada#moverHacia(Direccion)
     * @param direccion
     */
    public void avanzarHacia(Direccion direccion) {
        int xPrevio = this.getX();
        int yPrevio = this.getY();

        if (super.moverHacia(direccion)) {
            this.movimientos.add(direccion);
            this.direccion = direccion;
            actualizarEstela(xPrevio, yPrevio);
        }
    }

    /**
     * @return cantidad de combustible disponible en la nave
     */
    @Override
    public int obtenerCombustible() {
        return super.obtenerCombustible();
    }

    /**
     * @return nivel máximo de combustible
     */
    @Override
    int obtenerCombustibleMaximo() {
        return 150;
    }

    /**
     * @return la cantidad daño
     */
    @Override
    public int obtenerDaño() {
        return 35;
    }

    /**
     * @return la cantidad de combustible que consume realizar un movimiento
     */
    @Override
    int obtenerConsumoPorMovimiento() {
        return 7;
    }

    /**
     * @return la cantidad de combustible que consume al realizar un ataque
     */
    int obtenerConsumoPorAtaque() {
        return 10;
    }

    /**
     * {@inheritDoc}
     * post: verifica si se encuentra en el borde del escenario
     */
    @Override
    public boolean estaEnElBorde() {
        return super.estaEnElBorde();
    }

    /**
     * post: verifica si el casillero está vacío en una dirección
     * @param direccion
     */
    @Override
    public boolean hayVacioHacia(Direccion direccion) {
        return super.hayVacioHacia(direccion);
    }

    /**
     * post: verifica si hay un asteroide en una dirección
     * @param direccion
     */
    @Override
    public boolean hayAsteroideHacia(Direccion direccion) {
        return super.hayAsteroideHacia(direccion);
    }

    /**
     * post: verifica si hay un item en una direccion
     * @param direccion
     */
    @Override
    public boolean hayItemHacia(Direccion direccion) {
        return super.hayItemHacia(direccion);
    }

    /**
     * post: verifica si hay una nave en una direccion
     * @param direccion
     */
    @Override
    public boolean hayNaveHacia(Direccion direccion) {
        return super.hayNaveHacia(direccion);
    }

    /**
     * pre: La NaveDeAtaque {@link #puedeActuar()} <br>
     * post: Obtiene la salud de una NaveDeAtaqueEnemiga o Asteroide, en
     * cierta Direccion.
     * 
     * @param direccion
     * @return la salud de una nave enemiga o el tamaño de un asteroide
     */
    public int escanearIndicadorHacia(Direccion direccion) {
        int valor = 0;
        if (hayNaveHacia(direccion)) {
            NaveDeAtaqueEnemiga nave = (NaveDeAtaqueEnemiga) getOneObjectAtOffset(direccion.dx, direccion.dy,
                    NaveDeAtaqueEnemiga.class);
            valor = nave.obtenerSalud();
        } else if (hayAsteroideHacia(direccion)) {
            Asteroide asteroide = (Asteroide) getOneObjectAtOffset(direccion.dx, direccion.dy, Asteroide.class);
            valor = asteroide.obtenerTamaño();
        }
        return valor;
    }

    /**
     * post: actualiza la imagen cuando recoge a un Piloto
     * @param piloto
     */
    public void recibirPiloto(PilotoBase piloto) {
        this.piloto = piloto;
        actualizarImagen();
    }

    /**
     * post: baja al piloto
     */
    public void bajarPiloto() {
        this.piloto = null;
        actualizarImagen();
    }

    @Override
    /**
     * Actualiza la imagen de la nave de ataque para reflejar su estado actual en el mundo.
     * <p>
     * <b>Comportamiento:</b><br>
     * - Escala la imagen base de la nave según el tamaño de la celda del mundo.<br>
     * - Genera y dibuja la barra indicadora (vida/combustible) debajo de la nave, ajustando su color y proporción.<br>
     * - Rota la imagen para que coincida con la dirección actual de la nave.<br>
     * - Si la nave tiene un piloto, resalta el aura correspondiente sobre la imagen.<br>
     * - Si la nave tiene escudo activo, superpone la imagen del campo de fuerza sobre la nave.<br>
     * - Actualiza la imagen final mostrada en pantalla para reflejar todos los cambios visuales.
     * </p>
     * <b>Postcondición:</b> La imagen de la nave refleja fielmente su estado (dirección, barra de vida, escudo, piloto).
     */
    protected void actualizarImagen() {
        int tamCelda = getWorld().getCellSize();
        GreenfootImage image = getImage();
        image.scale((int) (tamCelda * ESCALA_X), (int) (tamCelda * ESCALA_Y));
        setImage(image);

        MyGreenfootImage canvas = new MyGreenfootImage(imagenBase.getWidth(),
                imagenBase.getHeight() + getWorld().getCellSize() / 3);

        canvas.setColor(Color.BLACK);
        canvas.fillRect(3, imagenBase.getHeight(), getWorld().getCellSize() - 1, 8);
        canvas.setColor(obtenerColorDeBarraIndicadora());

        canvas.fillRect(3, imagenBase.getHeight(),
            (int) ((getWorld().getCellSize() ) * obtenerProporcionDeBarraIndicadora())-2, 8);

        canvas.rotate(360 - direccion.rotacion);

        canvas.drawImage(imagenBase, 0, getWorld().getCellSize() / 6);
        setImage(canvas);

        if (this.piloto != null) {
            canvas.highlight(this.piloto.getAura());
        }

        //aplica el cambio de escudo 
        if (this.escudo > 0){
            GreenfootImage imgEscudo = new GreenfootImage("campoDeFuerza.png");
            imgEscudo.scale(tamCelda, tamCelda);
            int xEscudo = 0;
            int yEscudo = canvas.getHeight() - imgEscudo.getHeight() -7;
            canvas.drawImage(imgEscudo, xEscudo, yEscudo);
            int xNave = (canvas.getWidth() - imagenBase.getWidth()) / 2;
            int yNave = (canvas.getHeight() - imagenBase.getHeight()) / 2;
            canvas.drawImage(imagenBase, xNave, yNave); 
            setImage(canvas);

        }
    }

    /**
     * Actualiza la estela visual en la posición anterior de la nave.
     * pre: La estela permite visualizar el recorrido que realizó la nave.
     * Actualmente, la estela no se dibuja ya que la condición está configurada en {@code false}.
     * Si se desea que la estela sea visible, debe modificarse este valor a {@code true}.
     *
     * @param xPrevio la posición X anterior de la nave.
     * @param yPrevio la posición Y anterior de la nave.
     */

    private void actualizarEstela(int xPrevio, int yPrevio) {
        // La estela sirve para poder repasar el recorrido que realizó la nave, y de esa forma resolver errores.
        // Si deseas que la estela NO se dibuje, cambia este true por false
        if (false) {
            GreenfootImage fragmentoEstela = Estela.obtenerFragmentoEstela(this.movimientos, this.piloto.getAura(), getWorld());
            int tamCelda = getWorld().getCellSize();
            getWorld().getBackground().drawImage(fragmentoEstela, xPrevio * tamCelda, yPrevio * tamCelda);
        }
    }

    /**
     * Permite colocar una bomba si la nave posee la tarjeta activadora de bomba
     * pre: la nave debe poseer la tarjeta activadora de bomba ({@code this.tarjeta == true}) para colocar la bomba.
     * post: si la tarjeta está habilitada, se agrega una bomba al mundo en la posición actual de la nave.
     * @param nave
     * @param direccion
     */
    public void colocarBomba(NaveDeAtaque nave , Direccion direccion){
        if( this.tarjeta==true){
            this.direccion = direccion;
            actualizarImagen();
            setRotation(direccion.rotacion);
            Greenfoot.delay(20);
            Bomba bomba = new Bomba();
            getWorld().addObject(bomba, getX(), getY());
            nave.moverHacia(direccion);
            nave.moverHacia(direccion);
            nave.moverHacia(direccion);
            bomba.explotar();
        }
    }

    /**
     * Realiza un disparo láser en la dirección indicada, dejando una estela visual a su paso
     * El disparo avanza en línea recta desde la posición actual de la nave, generando fragmentos de estela que
     * visualizan el recorrido del láser. Si el láser impacta contra un objeto dañable, se reproduce un sonido
     * de disparo y se aplica daño al objeto impactado. La estela se elimina después del impacto o al completar
     * el recorrido si no se encuentra ningún obstáculo. 
     * 
     * pre: <li>la nave debe tener la capacidad de actuar ({@code puedeActuar()} debe devolver {@code true})<li>
     * 
     * post: <ul>
     * <li>Si la nave puede actuar, se consume combustible proporcional al costo del ataque.</li>
     * <li>Si se impacta contra un objeto dañable, se le aplica daño y se elimina la estela.</li>
     * <li>Si la nave no puede actuar, no se realiza ninguna acción.</li>
     * <ul>
     * @param direccion la dirección en la que se dispara el láser y se despliega la estela
     */
    public void disparoLaser(Direccion direccion) {
        if (!puedeActuar()) {
            return;
        }
        this.direccion = direccion;
        actualizarImagen();
        setRotation(direccion.rotacion);
        Greenfoot.delay(20);
        consumirCombustible(obtenerConsumoPorAtaque());
        List<Actor> fragmentosEstela = new ArrayList<>();

        for (int i = 1; i <= 10; i++) {
            int x = getX() + i * direccion.dx;
            int y = getY() + i * direccion.dy;
            LinkedList<Direccion> movimientoLaser = new LinkedList<>();
            movimientoLaser.add(direccion);
            Color colorLaser = new Color(255, 100, 100);
            GreenfootImage imagenEstela = Estela.obtenerFragmentoEstela(movimientoLaser, colorLaser, getWorld());
            Actor fragmentoEstela = new Actor() {};
            fragmentoEstela.setImage(imagenEstela);
            getWorld().addObject(fragmentoEstela, x, y);
            fragmentosEstela.add(fragmentoEstela);
            Greenfoot.delay(3);
            List<Actor> actores = getWorld().getObjectsAt(x, y, Actor.class);
            for (Actor actor : actores) {
                if (actor instanceof Dañable && actor != fragmentoEstela) {
                    Greenfoot.playSound("laser-shot.mp3");
                    ((Dañable) actor).recibirDañoDe(this);
                    removerEstelaDelLaser(fragmentosEstela);
                    return;
                }
            }
        }
        removerEstelaDelLaser(fragmentosEstela);
    }

    /**
     * post: elimina visualmente la estela del láser después de un impacto o al finalizar su recorrido.
     * @param fragmentos la lista de fragmentos de estela que deben ser eliminados del mundo
     */
    private void removerEstelaDelLaser(List<Actor> fragmentos) {
        Greenfoot.delay(15);
        for (Actor fragmento : fragmentos) {
            if (fragmento.getWorld() != null) {
                getWorld().removeObject(fragmento);
            }
        }
    }
}
