import greenfoot.*;
/**
 *Define el comportamiento de una Bomba
 */
public class Bomba extends ActorBase {
    private double ESCALA_X = 0.9;
    private double ESCALA_Y = 0.9;

    //Establece la imagen con la escala definida/
    @Override
    protected void actualizarImagen() {
        int tamCelda = getWorld().getCellSize();
        GreenfootImage image = getImage();
        image.scale((int) (tamCelda * ESCALA_X), (int) (tamCelda * ESCALA_Y));
        setImage(image);
    }

    /**
     * post: elimina los actores en un área 3x3 centrada en la bomba (excepto a sí misma,
     * paredes irrompibles, puertas cerradas y portales), muestra una animación de explosión,
     * reproduce un sonido y elimina la bomba del mundo.
     */
    public void explotar() {
        World mundo = getWorld();
        int x = getX();
        int y = getY();
        // Recorre los cuadros (3x3) centrados en la bomba
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                int nuevoX = x + dx;
                int nuevoY = y + dy;

                if (nuevoX >= 0 && nuevoY >= 0 && nuevoX < mundo.getWidth() && nuevoY < mundo.getHeight()) {
                    java.util.List<Actor> actores = mundo.getObjectsAt(nuevoX, nuevoY, Actor.class);
                    for (Actor a : actores) {
                        if (a != this && !(a instanceof ParedIrrompible) && 
                        !(a instanceof PuertaCerrada) && 
                        !(a instanceof PuertaDark) && 
                        !(a instanceof Portal)) {
                            mundo.removeObject(a);
                        }
                    }
                    ExplosionDeBomba explosion = new ExplosionDeBomba();
                    mundo.addObject(explosion, x, y);
                    explosion.animar();
                    mundo.removeObject(explosion);
                }
            }
        }
        Greenfoot.playSound("pixelExplosion.mp3");
        mundo.removeObject(this);
    }
}