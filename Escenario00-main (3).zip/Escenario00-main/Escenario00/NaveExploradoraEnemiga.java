/**
 * Define una NaveExploradora de la facción Enemiga
 */
public class NaveExploradoraEnemiga extends NaveEnemiga {
	
	/**
	 * {@inheritDoc}
	 */
	public NaveExploradoraEnemiga(Direccion direccion) {
		super(direccion);
	}
}
