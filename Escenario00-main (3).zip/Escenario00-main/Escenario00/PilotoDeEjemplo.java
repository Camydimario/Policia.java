/**
 *determina las acciones del piloto
 */
public class PilotoDeEjemplo extends PilotoBase {
    /**
     * el piloto se sube a la nave
     */
    @Override
    public void subirse(NaveDeAtaque nave) {
        super.subirse(nave);
    }

    /**
     * el piloto se baja de la nave
     */
    @Override
    public void bajarse() {
        super.bajarse();
    }

    /**
     * el piloto enciende los kmotores de la nave
     */
    void despegar() {
        navePilotada.encenderMotores();
        navePilotada.setDireccion(Direccion.ESTE);
    }

    /**
     * ataca a un asteroide de forma sistematica hasta destruir el asteroide
     */
    public int destruirAsteroideHacia(NaveDeAtaque nave,Direccion direccion) { 
        subirse(nave);
        nave.encenderMotores();
        int ataques = 0;
        while (navePilotada.hayAsteroideHacia(direccion)) {
            navePilotada.atacarHacia(direccion);
            ataques++;
        }
        return ataques;
    }

    /**
     * la nave de desplaza al SUR
     */
    void avanzarHaciaSur(NaveDeAtaque nave, int pasos){
        subirse(nave);
        nave.encenderMotores();
        for(int i = 0; i < pasos; i++){
            nave.avanzarHacia(Direccion.SUR);
        }

    }

    /**
     * la nave de desplaza al NORTE
     */
    void avanzarHaciaNorte(NaveDeAtaque nave, int pasos){
        subirse(nave);
        nave.encenderMotores();

        for(int i = 0; i < pasos; i++){
            nave.avanzarHacia(Direccion.NORTE);
            nave.abrirPuerta(Direccion.NORTE);
        }
    }

    /**
     * la nave de desplaza al ESTE
     */
    void avanzarHaciaEste(NaveDeAtaque nave, int pasos){
        subirse(nave);
        nave.encenderMotores();
        for(int i = 0; i < pasos; i++){
            nave.avanzarHacia(Direccion.ESTE);
        }
    }

    /**
     * la nave de desplaza al OESTE
     */
    void avanzarHaciaOeste(NaveDeAtaque nave, int pasos){
        subirse(nave);
        nave.encenderMotores();
        for(int i = 0; i < pasos;i++){
            nave.avanzarHacia(Direccion.OESTE);
            nave.abrirPuertaDark(Direccion.OESTE);
        }
    }

    void mision01(NaveDeAtaque nave){
        subirse(nave);
        nave.encenderMotores();
        nave.avanzarHacia(Direccion.ESTE);
        for(int i = 0; i < 6; i++){
            nave.avanzarHacia(Direccion.SUR);
        }
        for(int i = 0; i < 6; i++){
            nave.avanzarHacia(Direccion.ESTE);
        }
        for(int i = 0; i < 6; i++){
            nave.disparoLaser(Direccion.ESTE);
        }
        for(int i = 0; i < 6; i++){
            nave.avanzarHacia(Direccion.ESTE);
        }
        for(int i = 0; i < 5; i++){
            nave.avanzarHacia(Direccion.NORTE);
        }
        for(int i = 0; i < 3; i++){
            nave.disparoLaser(Direccion.ESTE);
        }
        for(int i = 0; i < 3; i++){
            nave.avanzarHacia(Direccion.ESTE);
        }
        for(int i = 0; i < 3; i++){
            nave.abrirPuerta(Direccion.NORTE);
            nave.avanzarHacia(Direccion.NORTE);
        }
        for(int i = 0; i < 2; i++){

            nave.avanzarHacia(Direccion.OESTE);

        }
        for(int i = 0; i < 2; i++){

            nave.avanzarHacia(Direccion.ESTE);

        }
        for(int i = 0; i < 3; i++){
            nave.avanzarHacia(Direccion.SUR);
        }
        nave.avanzarHacia(Direccion.OESTE);
        for(int i = 0; i < 3; i++){
            nave.avanzarHacia(Direccion.SUR);
        }
        for(int i = 0; i < 3; i++){
            nave.atacarHacia(Direccion.ESTE);
        }
        for(int i = 0; i < 2; i++){

            nave.avanzarHacia(Direccion.ESTE);
        }

    }

    void mision02(NaveDeAtaque nave ){
        subirse(nave);
        nave.encenderMotores();

        for(int i = 0; i < 2; i++){

            nave.avanzarHacia(Direccion.ESTE);
        }

        for(int i = 0; i < 2; i++){

            nave.avanzarHacia(Direccion.SUR);
        }

        nave.avanzarHacia(Direccion.ESTE);
        for(int i = 0; i < 3; i++){
            nave.atacarHacia(Direccion.ESTE);
        }

        for(int i = 0; i < 2; i++){

            nave.avanzarHacia(Direccion.ESTE);
        }
        for(int i = 0; i < 4; i++){

            nave.avanzarHacia(Direccion.SUR);
        }
        for(int i = 0; i < 3; i++){
            nave.disparoLaser(Direccion.ESTE);
        }
        for(int i = 0; i < 5; i++){

            nave.avanzarHacia(Direccion.ESTE);
        }
        for(int i = 0; i < 3; i++){
            nave.atacarHacia(Direccion.ESTE);
        }
        for(int i = 0; i < 3; i++){

            nave.avanzarHacia(Direccion.ESTE);
        }

        nave.colocarBomba(nave,Direccion.OESTE);

        for(int i = 0; i < 5; i++){

            nave.avanzarHacia(Direccion.ESTE);
        }
        for(int i = 0; i < 9; i++){

            nave.avanzarHacia(Direccion.OESTE);
        }
        for(int i = 0; i < 4; i++){
            nave.abrirPuertaDark(Direccion.OESTE);
            nave.avanzarHacia(Direccion.OESTE);
        }
        nave.avanzarHacia(Direccion.NORTE);
        nave.avanzarHacia(Direccion.SUR);
        for(int i = 0; i < 5; i++){

            nave.avanzarHacia(Direccion.ESTE);
        }
        for(int i = 0; i < 4; i++){

            nave.avanzarHacia(Direccion.NORTE);
        }
        for(int i = 0; i < 4; i++){

            nave.avanzarHacia(Direccion.OESTE);
        }
        for(int i = 0; i < 2; i++){

            nave.avanzarHacia(Direccion.NORTE);
        }
        for(int i = 0; i < 2; i++){

            nave.avanzarHacia(Direccion.OESTE);
        }
        for(int i = 0; i < 6; i++){

            nave.avanzarHacia(Direccion.NORTE);
        }
        for(int i = 0; i < 2; i++){

            nave.avanzarHacia(Direccion.OESTE);
        }
        nave.avanzarHacia(Direccion.NORTE);
        nave.avanzarHacia(Direccion.OESTE);
        nave.avanzarHacia(Direccion.SUR);
        for(int i = 0; i < 13; i++){

            nave.avanzarHacia(Direccion.OESTE);
        }
        for(int i = 0; i < 6; i++){

            nave.avanzarHacia(Direccion.NORTE);
        }
        nave.avanzarHacia(Direccion.OESTE);

    }
    void colocarBomba(NaveDeAtaque nave, Direccion direccion){
        nave.colocarBomba(nave,direccion);

    }

}
