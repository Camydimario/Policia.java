import greenfoot.*; // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class PuertaCerrada2 here.
 * 
 * @author (your name)
 * @version (a version number or a date)
 */
public class PuertaDark extends ActorBase {
    /**
     * Act - do whatever the PuertaCerrada2 wants to do. This method is called
     * whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void actualizarImagen() {
        int tamCelda = getWorld().getCellSize();
        GreenfootImage image = getImage();
        image.scale(tamCelda, tamCelda);
        setImage(image);
    }
    
    /**
     * Abre la puerta
     * post: se elimina la puerta
     */
    public void puertaAbiertaDark() {
        getWorld().removeObject(this);
    }
}




