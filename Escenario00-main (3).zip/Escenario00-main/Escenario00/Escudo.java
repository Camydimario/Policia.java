import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

    /**
     * define el comportamiento del item escudo 
     */
    public class Escudo extends ActorBase {
    /**
     * {@value #VIDA_ESCUDO}
     */
    private static final int VIDA_ESCUDO = 45;
    private double ESCALA_X = 0.9;
    private double ESCALA_Y = 0.9;
    
    /**
     * Establece la imagen con la escala definida
     */
    @Override
    protected void actualizarImagen() {
        int tamCelda = getWorld().getCellSize();
        GreenfootImage image = getImage();
        image.scale((int) (tamCelda * ESCALA_X), (int) (tamCelda * ESCALA_Y));
        setImage(image);
    }

    /**
     * post: el escudo desaparece del mundo
     * 
     * @return si el escudo fue recogido
     */
    public boolean serRecogido() {
        getWorld().removeObject(this);
        Greenfoot.delay(20);
        return true;
    }

}