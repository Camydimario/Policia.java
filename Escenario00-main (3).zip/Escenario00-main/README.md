# Escenario00

## Descripción

Escenario00 es un proyecto educativo basado en Greenfoot, orientado a la simulación de batallas espaciales con naves, asteroides, portales y diferentes objetos interactivos. El objetivo es aprender conceptos de programación orientada a objetos y lógica de videojuegos.

## Instrucciones de uso

1. Clona o descarga este repositorio en tu computadora.
2. Abre el proyecto en Greenfoot.
3. Realiza tus modificaciones o agrega nuevas funcionalidades según las consignas del trabajo.
4. Prueba el funcionamiento ejecutando el escenario en Greenfoot.
5. Antes de subir tus cambios, verifica que todo funcione correctamente y que la documentación esté actualizada.
6. Sube tus cambios a GitHub con un mensaje descriptivo del trabajo realizado.

## Estructura del proyecto

- `Escenario00/`  
  Contiene todas las clases Java del proyecto, imágenes y archivos de configuración de Greenfoot.
- `README.md`  
  Este archivo de ayuda.
- `LICENSE`  
  Licencia del proyecto.

## Requisitos

- [Greenfoot](https://www.greenfoot.org/) instalado en tu equipo.
- Java JDK compatible con Greenfoot.

## Notas

- No olvides actualizar la documentación de tus métodos y clases.

---

## Integrantes
-Hector Duarte

-Zulma Fernández

-Jesus Hovakimyan

![image](https://github.com/user-attachments/assets/f98b266b-f75c-41d7-9d19-2bd8b1f5a702)

